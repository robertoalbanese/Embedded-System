/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

#include <xc.h>

int button_E8_pressed(int *prev); //Routine to check if the button S5 has been pressed
int button_D0_pressed(int *prev); //Routine to check if the button S5 has been pressed

