/* 
 * File:   timer.h
 * Author:  ralba & andre
 * Comments:
 * Revision history: 
 */

#include <xc.h> // include processor files - each processor file is guarded.

void adc_config();