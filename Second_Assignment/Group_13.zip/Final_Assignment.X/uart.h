/* 
 * File:   uart.h
 * Author:  andre& ralba
 * Comments:
 * Revision history: 
 */

#include <xc.h> // include processor files - each processor file is guarded.  

void UART_config(); //Routine to counfigure UART