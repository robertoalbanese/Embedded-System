/*
 * File:   buttons.h
 * Author: ralba & andre
 *
 * Created on January 12, 2020, 6:46 PM
 */

#ifndef XC_HEADER_BUTTONS_H
#define XC_HEADER_BUTTONS_H

#include <xc.h> 
#include "timer.h"

void buttons_config(); // Configuration of buttons

#endif