/*
 * File:   newmainXC16.c
 * Author: ralba
 *
 * Created on January 20, 2021, 1:08 PM
 */


#include "xc.h"

int main(void) {
    return 0;
}
