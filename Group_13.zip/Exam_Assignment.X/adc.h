/* 
 * File:   timer.h
 * Author: ralba & andre
 *
 * Created on January 12, 2020, 6:46 PM
 */

#ifndef XC_HEADER_ADC_H
#define XC_HEADER_ADC_H

#include <xc.h> // include processor files - each processor file is guarded.

void adc_config(); // Configuration of A/D converter 

#endif